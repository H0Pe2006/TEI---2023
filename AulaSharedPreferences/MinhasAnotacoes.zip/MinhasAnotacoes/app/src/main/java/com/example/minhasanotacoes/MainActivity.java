package com.example.minhasanotacoes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    private AnotacaoPreferencias preferencias;
    private EditText editAnotacao;

    private Button buttonSalvar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        preferencias = new AnotacaoPreferencias(getApplication());

        editAnotacao = findViewById(R.id.editTextTextMultiLine);

        buttonSalvar = findViewById(R.id.buttonSalvar);

        buttonSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //validar se o usuario digitou algo
                String textoRecuperado = editAnotacao.getText().toString();
                if(textoRecuperado.equals("")){
                    Snackbar.make(view, "Preencha a anotacao", Snackbar.LENGTH_LONG).show();
                }
                else{
                    preferencias.salvarAnotacoes(textoRecuperado);
                    Snackbar.make(view, "Anotação salva com sucesso!!", Snackbar.LENGTH_LONG).show();

                }
            }
        });

        //recuperar anotacao

        String anotacao = preferencias.recuperarAnotacoes();
        if(!anotacao.equals("")){
            editAnotacao.setText(anotacao);
        }
    }
}